import React, { useState } from 'react'
import "./Contact.css"


const Contact = () => {
    const [done, setDone] = useState(false);
  return (
    <div className="contact-form" id="Contact">
        <div className="c-left">
            <div className="awesome">
                <span>Get in touch</span>
                <span>Contact Us</span>
                <div className="blur s-blur1" style={{background:"#ABF1FF94"}}></div>
            </div>
        </div>

        <div className="c-right">
            <form method="POST" className="form">
                <input type="text" name="user_name" className='user' placeholder='Name' />
                <input type="tel" name="user_phone" className='user' placeholder='Phone number' />
                <textarea name="message" className='user' placeholder='Message'/>
                <input type="submit" value="Send" className='button'/>
                <div className='blur c-blur1' style={{background:"var(--purple)"}}></div>
                <span>{done && "Message sent succesfully, we will get back to you shortly"}</span>

            </form>
        </div>
    </div>
  )
}

export default Contact