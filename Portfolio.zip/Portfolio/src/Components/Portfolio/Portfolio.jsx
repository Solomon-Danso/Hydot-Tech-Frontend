import React from 'react'
import "./Portfolio.css"
import Sidebar from "../../img/sidebar.png"
import Ecommerce from "../../img/ecommerce.png"
import HOC from "../../img/hoc.png"
import MusicApp from "../../img/musicapp.png"
import PortCard from "./PortCards"
import {motion} from "framer-motion"



const Portfolio = () => {
  return (
    <div className="portfolio" id="Portfolio">
        <span>Recent Projects</span>
        <span>Portfolio</span>

        <div className="p-cards">
    <div
    
    >
        <a href="/">
        <PortCard
    image={Sidebar}
    header ={"Programming"}
    detail = {"Python, Java, C++, C, Dart, Javascript, PHP,Python, Java, C++, C, Dart, Javascript, PHP "}
    />
        </a>
     </div>


     <motion.div
    initial={{rotate:45}}
    whileInView={{rotate:0}}
    transition={{duration:3, type:'spring'}}
     
     >
     <a href="/">
     <PortCard
    image={HOC}
    header ={"Services"}
    detail = {"Websites || Softwares || Cyber Security || AI developer || Network Admin || System Admin"}
    />
     </a>
     </motion.div>

     <motion.div
     initial={{rotate:45}}
     whileInView={{rotate:0}}
     transition={{duration:3, type:'spring'}}
 
     >
        <a href="/">
        <PortCard
    image={MusicApp}
    header ={"Industries"}
    detail = {"Schools || Health || Retail and wholesale || Automobile || Banking Sector || Others"}
    />
        </a>    
     </motion.div>

     <motion.div
     initial={{rotate:45}}
     whileInView={{rotate:0}}
     transition={{duration:3, type:'spring'}}
 
     >
        <a href="/">
        <PortCard
    image={Ecommerce}
    header ={"Industries"}
    detail = {"Schools || Health || Retail and wholesale || Automobile || Banking Sector || Others"}
    />
        </a>    
     </motion.div>
 
    </div>

    </div>
  )
}

export default Portfolio