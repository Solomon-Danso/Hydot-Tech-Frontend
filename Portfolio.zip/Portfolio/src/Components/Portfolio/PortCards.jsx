import React from 'react'
import "./PortCards.css"
import { themeContext } from '../../Context';
import { useContext } from "react";

const PortCards = ({image, header, detail}) => {
  const theme = useContext(themeContext);
  const darkMode = theme.state.darkMode;
  
  return (

    
    <div className="portcards"
    style={{
      background:darkMode?'white':'',
      color:darkMode?'black':''
    }}
    >
        <img src={image} alt="" />
        <span>{header}</span>
        <span>{detail}</span>
        <button className="button">LEARN MORE</button>

    </div>
  )
}

export default PortCards