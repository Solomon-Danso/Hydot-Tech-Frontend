import React from 'react'
import "./Intro.css"
import Github from "../../img/github.png"
import LinkedIn from "../../img/linkedin.png"
import Instagram from "../../img/instagram.png"
import Vector1 from "../../img/Vector1.png"
import Vector2 from "../../img/Vector2.png"
import Boy from "../../img/boy.png"
import Thumbup from "../../img/thumbup.png"
import Crown from "../../img/crown.png"
import Glassesimoji from "../../img/glassesimoji.png"
import FloatingDiv from '../FloatingDiv/FloatingDiv'
import { themeContext } from '../../Context';
import { useContext } from "react";
import {motion} from "framer-motion"


const Intro = () => {

const transition = {duration:2, type:'spring'}

const theme = useContext(themeContext);
  const darkMode = theme.state.darkMode;
  
  return (
    <div className="intro">
        <div className="i-left">
        <div className="i-name">
            <span style={{color:darkMode?'white':''}}>Welcome To</span>
            <span>Hydot Tech</span>
            <span>Excellent Web development, Software Engineering, Cyber Security, Artificial Intelligence and Data Science projects </span>
        </div>
       <button className="button i-button">Hire Us</button>
       <div className="i-icons">
        <img src={Github} alt="" />
        <img src={LinkedIn} alt="" />
        <img src={Instagram} alt="" />
       </div>
      
        </div>

        <div className="i-right">
          <img src={Vector1} alt=""/>
          <img src={Vector2} alt=""/>
          <img src={Boy} alt=""/>
          <motion.img 
          initial={{left:'-50%'}}
          whileInView={{left:"-24%"}}
          whileHover={{left:"-14%"}}
          transition={transition}
          src={Glassesimoji} alt=""/>
      
        <motion.div
        className='floating-div' 
        initial={{top:'-4%',left:"74%"}}
        whileInView={{left:"68%"}}
        whileHover={{left:"48%"}}
        transition={transition}
        style={{top:"-4%",left:"68%"}}>
          <FloatingDiv image={Crown} txt1="Web" txt2="Developer" />
        </motion.div>

        <motion.div
        initial={{left:'9rem', top:'18rem'}}
        whileInView={{left:'0rem',top:"18rem"}}
        whileHover={{left:'4rem', top:'18rem'}}
        transition={transition}
        className='floating-div'

        style={{top:"18rem",left:"0rem"}}>
        <FloatingDiv image={Thumbup} txt1="Software" txt2="Developer" />
        </motion.div>
      
          <div className="blur" style={{background:"rgb(238 210 255"}}></div>
          <div className="blur" style={{
            background:"#C1F5FF",
            top:'17rem',
            width:'21rem',
            height:'11rem',
            left:'-9rem'
          }}></div>
        



        </div>
    </div>
  )
}

export default Intro