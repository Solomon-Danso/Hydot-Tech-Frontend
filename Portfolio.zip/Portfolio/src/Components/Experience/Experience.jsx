import React from 'react'
import "./Experience.css"
import { themeContext } from '../../Context';
import { useContext } from "react";
import {motion} from "framer-motion"


const Experience = () => {

    const theme = useContext(themeContext);
    const darkMode = theme.state.darkMode;
    

  return (
    <div className="experience" id="Experience">
        <div className="achievment" >
            <motion.div
            initial={{rotate:360}}
            whileInView={{rotate:0}}
            transition={{duration:2,type:"spring"}}
            className="circle" style={{
      background:darkMode?'white':'',
      color:darkMode?'black':''
    }}>8+</motion.div>

            <span>years</span>
            <span>Experience</span>
        </div>

        <div className="achievment">
            <motion.div
            initial={{rotate:360}}
            whileInView={{rotate:0}}
            transition={{duration:2,type:"spring"}}

            className="circle"style={{
      background:darkMode?'white':'',
      color:darkMode?'black':''
    }}>100+</motion.div>
            <span>completed</span>
            <span>Project</span>
        </div>

        <div className="achievment">
            <motion.div
            initial={{rotate:360}}
            whileInView={{rotate:0}}
            transition={{duration:2,type:"spring"}}

            className="circle"style={{
      background:darkMode?'white':'',
      color:darkMode?'black':''
    }}>5+</motion.div>
            <span>tech</span>
            <span>Domains</span>
        </div>

        <div className="achievment">
            <motion.div
            initial={{rotate:360}}
            whileInView={{rotate:0}}
            transition={{duration:2,type:"spring"}}

            className="circle"style={{
      background:darkMode?'white':'',
      color:darkMode?'black':''
    }}>6+</motion.div>
            <span>tech</span>
            <span>Frameworks</span>
        </div>

        <div className="achievment">
            <motion.div
            initial={{rotate:360}}
            whileInView={{rotate:0}}
            transition={{duration:2,type:"spring"}}

            className="circle"style={{
      background:darkMode?'white':'',
      color:darkMode?'black':''
    }}>7+</motion.div>
            <span>programming</span>
            <span>Languages</span>
        </div>

    </div>
  )
}

export default Experience