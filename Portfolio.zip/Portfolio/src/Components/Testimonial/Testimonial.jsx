import React from 'react'
import "./Testimonial.css"



const Testimonial = () => {

  return (
    <div className="t-wrapper" id="Testimonials">

<div

className="t-heading">
    <span>Client always get </span>
    <span>Exceptional work</span>
    <span> from me...</span>
    <div className="t-blur1 blur" style={{background:"var(--purple)"}}></div>
    <div className="t-blur2 blur" style={{background:"skyblue"}}></div>  
</div>



    </div>
  )
}

export default Testimonial