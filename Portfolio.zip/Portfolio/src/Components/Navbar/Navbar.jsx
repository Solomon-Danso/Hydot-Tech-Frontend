import React from 'react'
import Toogle from '../Toogle/Toogle'
import "./Navbar.css"
import {Link} from 'react-scroll'


const Navbar = () => {
  return (
    <div className="n-wrapper">

    <div className="n-left">
        <div className="n-name">HydotTech</div>
        <Toogle/>
    </div>

    <div className="n-right">
        <div className="n-list">
            <ul style={{listStyleType:'none'}}>
               
               <Link spy={true} to="Navbar" activeClass='activeClass' smoooth={true}>
               <li>Home</li>
               </Link>
               
               <Link spy={true} to='Services' activeClass='activeClass' smoooth={true}>
               <li>Services</li>
               </Link>
                
               <Link spy={true} to='Experience' activeClass='activeClass' smoooth={true}>
               <li>Experience</li>
               </Link>

               <Link spy={true} to='Portfolio' activeClass='activeClass' smoooth={true}>
               <li>Portfolio</li>
                </Link>

               <Link spy={true} to='Testimonials' activeClass='activeClass' smoooth={true}>
               <li>Testimonials</li>
               
               </Link>
                
              
            
            </ul>
        </div>
        <button className="button n-button">
        <Link spy={true} to='Testimonials' activeClass='activeClass' smoooth={true}>
        Contact
        </Link>           
        </button>
    </div>

    </div>
  )
}

export default Navbar