import React from 'react'
import "./Services.css"
import HeartEmoji from "../../img/heartemoji.png"
import Glasses from "../../img/glasses.png"
import Humble from "../../img/humble.png"
import Card from '../Card/Card'
import Flutter from "./flutter.pdf"
import {motion} from "framer-motion"


const Services = () => {

  const transition = {duration:2, type:'spring'}

  return (
   <div className="services" id="Services">
    {/*Left Side */}
    <div className="awesome">
    <span>Our Unique</span>
    <span>Services</span>
    <span>We provide wide range of services which includes:<br/>Web development, Software Development, Cyber Security, Artificial Intelligence(AI) development, Network Engineering, System administration and Help disk </span>
    <a href={Flutter} download>
    <button className="button s-button">Download</button>
    </a>
    <div className="blur s-blur1" style={{background:"*#ABF1FF94"}}></div>
    
    </div>
    
    
    
    {/*Right side*/}
    <div className="cards">
    <motion.div
    initial={{top:'20rem',left:'0rem'}}
    whileInView={{top:'20rem',left:'-25rem'}}
    transition={transition}
    whileHover={{top:'20rem',left:'-22rem'}}
    
    style={{top:'20rem',left:'-25rem'}}>
      <Card
    emoji={Glasses}
    heading ={"Programming"}
    detail = {"Python, Java, C++, C, Dart, Javascript, PHP "}
    />
    
     </motion.div>

     <motion.div
     initial={{top:"0rem",left:'-10rem'}}
     whileInView={{top:"12rem",left:'-10rem'}}
     transition={transition}
     whileHover={{top:"10rem",left:'-10rem'}}


     style={{top:"12rem",left:'-10rem'}}>
      <Card
    emoji={Humble}
    heading ={"Services"}
    detail = {"Websites || Softwares || Cyber Security || AI developer || Network Admin || System Admin"}
    />
    
     </motion.div>

     <motion.div
     initial={{top:"25rem",right:'-3rem'}}
     whileInView={{top:"30rem",right:'-3rem'}}
     transition={transition}
     whileHover={{top:"28rem",right:'-3rem'}}


     style={{top:"30rem",right:'-3rem'}}>
      <Card
    emoji={HeartEmoji}
    heading ={"Industries"}
    detail = {"Websites || Softwares || Cyber Security || AI developer || Network Admin || System Admin"}
    />
    
     </motion.div>
    <div className="spacer"></div>

     <div className="blur s-blur2" style={{background:"var(--purple)"}}></div>

    </div>

   </div>
  )
}

export default Services